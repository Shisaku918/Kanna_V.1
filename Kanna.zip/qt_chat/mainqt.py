# N'oubliez pas de mettre à jour les importations si nécessaire
from typing import Optional
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPushButton, QLabel, QListWidget, QListWidgetItem, QMessageBox, QDialog, QLineEdit
from PySide6.QtGui import Qt, QFont, QTextOption
from PySide6.QtCore import QSize
from button_image import ImageButton
import torch
import sys
import pickle
import os
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import colorful as cf

# Définition du nom du fichier pour stocker les données
MEMORY_FILE = "shiassistant_memory.pickle"

PASSWORD = "mdp"

class PasswordDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Mot de passe requis")
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout(self)

        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)

        submit_button = QPushButton("Login", self)
        submit_button.clicked.connect(self.check_password)
        layout.addWidget(submit_button)

    def check_password(self):
            password = self.password_input.text()
            if password == PASSWORD:
                self.accept()
            else:
                QMessageBox.warning(self, "Mot de passe incorrect", "Le mot de passe est incorrect. Veuillez réessayer.")

# Fonction pour enregistrer la mémoire sur le disque
def save_memory(memory):
    with open(MEMORY_FILE, "wb") as file:
        pickle.dump(memory, file)

# Fonction pour charger la mémoire depuis le disque (si le fichier existe)
def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "rb") as file:
            return pickle.load(file)
    return {}

# Fonction pour afficher les questions mémorisées
def list_questions(memory):
    return ["Voici la liste des questions mémorisées :"] + [f"・ {question}" for question in memory]

# Fonction pour supprimer une mémorisation
def delete_memory(memory, question):
    if question in memory:
        del memory[question]
        save_memory(memory)
        return "Mémorisation supprimée avec succès."
    else:
        return "La question demandée n'est pas mémorisée."

# Fonction pour modifier une mémorisation
def modify_memory(memory, question, new_answer):
    if question in memory:
        memory[question] = new_answer
        save_memory(memory)
        return "Mémorisation modifiée avec succès."
    else:
        return "La question demandée n'est pas mémorisée."

# Fonction pour post-traiter la réponse générée par l'IA Kanna
def filter_response_postprocessing(cadet_tiny_response, original_input):
    # Ajoutez ici tout traitement supplémentaire de la réponse générée par l'IA Kanna, si nécessaire.
    return cadet_tiny_response

# Fonction pour obtenir la réponse du ChatBot à partir de l'IA Kanna
def filter_response(memory, response, original_input):
    # Vérifier si la question est déjà mémorisée, si oui, renvoyer la réponse correspondante
    if original_input in memory:
        return memory[original_input]
    
    # Sinon, créer une instance de la classe KannaAgent et appeler sa méthode generate
    kanna_agent = KannaAgent()  # Crée une instance de la classe KannaAgent
    situation_narrative = "Imagine you are Kanna talking to ???."
    role_instruction = "You are Kanna, and you are talking to ???."
    cadet_tiny_response = kanna_agent.generate(situation_narrative, role_instruction, original_input)

    # Appliquer le filtre à la réponse générée par l'IA
    generated_response = filter_response_postprocessing(cadet_tiny_response, original_input)
    return generated_response

def get_response_from_memory(memory, question):
    return memory.get(question, "")


class Kanna(QWidget):
    def __init__(self, memory) -> None:
        super().__init__()
        self.initUI()
        self.memory = memory
        self.agent = KannaAgent()

    def initUI(self):
        self.setWindowTitle("Kanna")
        self.setGeometry(650, 150, 500, 700)
        self.setStyleSheet("background-color: black;")

        layout_main = QVBoxLayout(self)

        layout_help_button = QVBoxLayout()
        help_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/help.png"))
        help_button.clicked.connect(self.show_help)
        layout_help_button.addWidget(help_button, alignment=Qt.AlignBottom | Qt.AlignLeft)
        layout_main.insertLayout(0, layout_help_button)  # Insérer le layout du bouton "Help" au début de layout_main

        self.messages_list = QListWidget(self)
        self.messages_list.setStyleSheet("background-color: black; color: white; border: none;")
        self.messages_list.setFixedHeight(600)  # Reduce the height to leave space for the send bar
        self.messages_list.setFixedWidth(500)
        layout_main.addWidget(self.messages_list, alignment=Qt.AlignTop | Qt.AlignLeft)

        layout_send_bar = QHBoxLayout()

        self.send_bar = QTextEdit(self)
        self.send_bar.setStyleSheet("border: 1px solid purple; border-radius: 15px; background-color: white; margin-bottom: 10px;")
        self.send_bar.setPlaceholderText("Écrivez votre message ici...")
        self.send_bar.setFixedHeight(70)
        self.send_bar.setFixedWidth(410)
        layout_send_bar.addWidget(self.send_bar, alignment=Qt.AlignBottom | Qt.AlignLeft)

        self.send_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/send.png"))
        self.send_button.clicked.connect(self.send_message)
        layout_send_bar.addWidget(self.send_button, alignment=Qt.AlignBottom | Qt.AlignRight)

        layout_main.addLayout(layout_send_bar)

        
    def check_for_memory_match(self, user_input):
        for question in self.memory:
            if question.lower() in user_input.lower():
                return self.memory[question]
        return None

    def send_message(self):
        user_input = self.send_bar.toPlainText()
        if user_input == "[RESET]":
            self.agent.reset_history()
            self.add_message("Kanna", "[Conversation history cleared. Chat with Kanna!]")
        elif user_input == "[END]":
            save_memory(self.memory)  # Sauvegarde avant de quitter
            sys.exit(app.quit())
        else:
            # Vérifier s'il y a une correspondance avec une question mémorisée
            memory_response = self.check_for_memory_match(user_input)
            if memory_response:
                self.add_message("You", user_input)
                self.add_message("Kanna", memory_response)
            else:
                response = self.agent.generate("Imagine you are Kanna talking to ???.", "You are Kanna, and you are talking to ???.", user_input)
                if user_input.startswith("$"):
                    self.process_command(user_input)
                else:
                    self.add_message("You", user_input)
                    self.add_message("Kanna", response)
        self.send_bar.clear()
        self.messages_list.scrollToBottom()

    def add_message(self, author, message):
        item = QListWidgetItem(self.messages_list)
        item.setSizeHint(QSize(0, 80))  # Set the size of the item (réduire la hauteur des éléments de la liste)
        widget = QWidget(self.messages_list)  # Create a widget for the item
        layout = QHBoxLayout(widget)  # Use QHBoxLayout to align the profile image and message horizontally
        layout.setContentsMargins(5, 5, 5, 5)  # Set margins for the layout
        label = QLabel(message)
        label.setStyleSheet("background-color: #E8E8E8; color: black; border-radius: 15px; padding: 10px;")
        label.setFont(QFont("Arial", 12))  # Apply custom font and size to the label
        label.setWordWrap(True)  # Enable word wrap for the label
        if author == "You":
            layout.addWidget(label, alignment=Qt.AlignTop | Qt.AlignRight)  # Align message label to the top-right for "You"
        else:
            layout.addWidget(label, alignment=Qt.AlignTop | Qt.AlignLeft)  # Align message label to the top-left for "Kanna"
        widget.setLayout(layout)
        self.messages_list.setItemWidget(item, widget)

    def process_command(self, command):
        response = ""
        try:
            command, *data = command.split("||")
            data = '||'.join(data).strip()
            match command:
                case "$add":
                    response = self.add(data)
                case "$list":
                    response = self.list_questions()
                case "$supprimer":
                    response = self.supprimer(data)
                case "$modifier":
                    response = self.modifier(data)
                case "$help":
                    response = self.show_help()
                case "$quit":
                    self.quit_app()
                case _:
                    response = "Commande invalide."
        except:
            response = "Format de commande invalide. Assurez-vous d'inclure les détails requis (question, réponse, etc.) séparés par '::'."

        self.add_message("Kanna", response)

    def quit_app(self):
        save_memory(self.memory)  # Sauvegarder la mémoire avant de quitter
        app.quit()

    def add(self, data):
        try:
            question, answer = data.split("::")
            self.memory[question.strip()] = answer.strip()
            save_memory(self.memory)
            return "Mémorisé! Je me souviendrai de cette question."
        except:
            return "Format de commande invalide pour l'ajout. Assurez-vous d'inclure la question et la réponse séparées par '::'."

    def list_questions(self):
        return "\n".join(list_questions(self.memory))

    def supprimer(self, data):
        question_to_delete = data
        return delete_memory(self.memory, question_to_delete)

    def modifier(self, data):
        try:
            question_to_modify, new_answer = data.split("::")
            return modify_memory(self.memory, question_to_modify.strip(), new_answer.strip())
        except:
            return "Format de commande invalide pour la modification. Assurez-vous d'inclure la question et la nouvelle réponse séparées par '::'."

    def help(self):
        return """
        Commandes disponibles :

        $add||question::réponse - Pour ajouter une question et sa réponse dans la mémoire.
        $list - Pour afficher la liste des questions mémorisées.
        $supprimer||question - Pour supprimer une question mémorisée.
        $modifier||question::nouvelle_réponse - Pour modifier la réponse d'une question mémorisée.
        $quit - Pour quitter l'application.
        """


    def show_help(self):
        help_text = self.help()
        help_window = HelpWindow(help_text, parent=self)
        help_window.exec_()

class HelpWindow(QDialog):
    def __init__(self, help_text, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Aide")
        self.setStyleSheet("background-color: white; color: black;")

        layout = QVBoxLayout(self)
        label = QLabel(help_text)
        layout.addWidget(label)
    

class KannaAgent:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained("t5-small", model_max_length=512)
        self.model = AutoModelForSeq2SeqLM.from_pretrained("ToddGoldfarb/Cadet-Tiny").to(self.device)
        self.conversation_history = ""

    def observe(self, observation):
        self.conversation_history = self.conversation_history + observation
        if len(self.conversation_history) > 400:
            self.conversation_history = self.conversation_history[112:]

    def set_input(self, situation_narrative="", role_instruction=""):
        input_text = "dialogue: "
        if situation_narrative != "":
            input_text = input_text + situation_narrative

        if role_instruction != "":
            input_text = input_text + " <SEP> " + role_instruction

        input_text = input_text + " <TURN> " + self.conversation_history
        return input_text

    def generate(self, situation_narrative, role_instruction, user_response):
        user_response = user_response + " <TURN> "
        self.observe(user_response)

        input_text = self.set_input(situation_narrative, role_instruction)

        inputs = self.tokenizer([input_text], return_tensors="pt").to(self.device)
        
        outputs = self.model.generate(inputs["input_ids"], max_new_tokens=512, temperature=0.75, top_p=.95,
                                      do_sample=True)
        cadet_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        added_turn = cadet_response + " <TURN> "
        self.observe(added_turn)

        return cadet_response

    def reset_history(self):
        self.conversation_history = []


if __name__ == "__main__":
    app = QApplication()

    # Demander le mot de passe avant de créer la fenêtre principale
    password_dialog = PasswordDialog()
    if password_dialog.exec_() == QDialog.Accepted:
        # Charger la mémoire depuis le disque (ou créer une nouvelle mémoire)
        memory = load_memory()

        window = Kanna(memory)  # Passer la mémoire à la classe Kanna
        window.show()
        sys.exit(app.exec_())
