from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QFrame
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtCore import Qt, QSize
import os
import sys

class ImageButton(QPushButton):
    def __init__(self, pixmap_path):
        super().__init__()
        self.pixmap = QPixmap(pixmap_path)
        self.setIcon(self.pixmap)
        self.setIconSize(QSize(80, 80))
        self.setStyleSheet("background-color: transparent; border: none;")
        self.setCursor(Qt.PointingHandCursor)